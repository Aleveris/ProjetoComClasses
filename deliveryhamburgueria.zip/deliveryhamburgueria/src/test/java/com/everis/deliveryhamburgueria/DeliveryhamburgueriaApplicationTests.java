package com.everis.deliveryhamburgueria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeliveryhamburgueriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
